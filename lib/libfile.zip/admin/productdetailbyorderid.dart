import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

class Productdetailbyorderid extends StatefulWidget {
  final String queryDocumentSnapshot1, queryDocumentSnapshot2;
  Productdetailbyorderid(
      {required this.queryDocumentSnapshot1,
      required this.queryDocumentSnapshot2});

  @override
  _ProductdetailbyorderidState createState() => _ProductdetailbyorderidState();
}

class _ProductdetailbyorderidState extends State<Productdetailbyorderid> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection('order')
              .doc('${widget.queryDocumentSnapshot2}')
              .collection('pendingorder')
              .doc('${widget.queryDocumentSnapshot1}')
              .collection('subcoll')
              .snapshots(),
          builder: (BuildContext context, AsyncSnapshot snapshot) {
            if (!snapshot.hasData) {
              return Center(child: Text('no data'));
            } else if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(
                child: CircularProgressIndicator(),
              );
            }
            // Timer(Duration(seconds: 2), () {});
            return Container(
              child: ListView.builder(
                itemCount: snapshot.data.docs.length,
                itemBuilder: (BuildContext context, int index) {
                  // print(snapshot.data.docs.length);
                  return Container(
                    color: Colors.amber,
                    height: 60,
                    child: Center(
                      child: Text("${snapshot.data.docs[index]['title']}"),
                    ),
                  );
                },
              ),
            );
          },
        ),
      ),
    );
  }
}
