import 'package:flutter/material.dart';

class Editrecomended extends StatelessWidget {
  const Editrecomended({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
