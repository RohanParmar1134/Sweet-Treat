import 'package:eva_icons_flutter/eva_icons_flutter.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:location/location.dart';
import 'package:online_bakery_shop/alldatabase/recomended.dart';
import 'package:online_bakery_shop/provider/homedrawerprovider.dart';
import 'package:online_bakery_shop/provider/maps.dart';
import 'package:online_bakery_shop/screen/all_auth/authscreen/signin.dart';
import 'package:online_bakery_shop/screen/all_auth/authservice/services/Authentification.dart';
import 'package:online_bakery_shop/screen/all_auth/authservice/services/google_maps.dart';
import 'package:online_bakery_shop/screen/all_main_screen/cart.dart';
import 'package:provider/provider.dart';

class Homepage extends StatefulWidget {
  const Homepage({Key? key}) : super(key: key);

  @override
  _HomepageState createState() => _HomepageState();
}

FirebaseAuth _auth = FirebaseAuth.instance;
User? users = _auth.currentUser;

class _HomepageState extends State<Homepage> {
  @override
  Widget build(BuildContext context) {
    // String? useremail = _auth.currentUser?.email;
    String? useremail =
        Provider.of<Authentication>(context, listen: false).useremail;
    String? username = _auth.currentUser?.displayName;
    String? userphotourl = _auth.currentUser?.photoURL;
    String logoutsucess = 'Logout Sucessfully';
    var draweranimation = Provider.of<Homedrawerprovider>(context);
    double? xoffset = draweranimation.getxoffset;
    double? yoffset = draweranimation.getyoffset;
    double? scalefactor = draweranimation.getscalefactor;
    bool drawerstatus = draweranimation.getdrawerstatus;
    return AnimatedContainer(
      decoration: BoxDecoration(
        borderRadius: drawerstatus == true
            ? BorderRadius.only(topLeft: Radius.circular(80))
            : BorderRadius.zero,
        color: Colors.black,
      ),
      duration: Duration(milliseconds: 250),
      transform: Matrix4.translationValues(xoffset!, yoffset!, 0)
        ..scale(scalefactor),
      child: Scaffold(
          backgroundColor: Color(0xFFC58140),
          // backgroundColor: Colors.orange[400],
          // appBar: AppBar(
          //   shape: RoundedRectangleBorder(
          //       borderRadius: drawerstatus == true
          //           ? BorderRadius.only(topLeft: Radius.circular(80))
          //           : BorderRadius.zero),
          //   elevation: 0,
          //   backgroundColor: Colors.orange,
          //   leading: drawerstatus == false
          //       ? IconButton(
          //           onPressed: () {
          //             draweranimation.opendrawer();
          //           },
          //           icon: Icon(CupertinoIcons.list_bullet_indent,
          //               color: Colors.white))
          //       : IconButton(
          //           onPressed: () {
          //             draweranimation.closedrawer();
          //           },
          //           icon: Icon(EvaIcons.arrowBack)),
          //   title: Center(
          //     child: RichText(
          //         text: TextSpan(
          //             style: Theme.of(context).textTheme.headline6?.copyWith(
          //                 fontWeight: FontWeight.w800, fontFamily: 'poppins'),
          //             children: [
          //           TextSpan(
          //               text: 'Sweet', style: TextStyle(color: Colors.white)),
          //           TextSpan(
          //               text: 'Treets',
          //               style: TextStyle(color: Colors.deepOrange))
          //         ])),
          //   ),
          //   actions: [
          //     IconButton(
          //         onPressed: () {
          //           Navigator.push(context,
          //               MaterialPageRoute(builder: (context) {
          //             return Cart();
          //           }));
          //         },
          //         icon: Icon(CupertinoIcons.cart, color: Colors.white))
          //   ],
          // ),
          body: Container(
            decoration: BoxDecoration(
                borderRadius: drawerstatus == true
                    ? BorderRadius.only(
                        topLeft: Radius.circular(50),
                        bottomLeft: Radius.circular(50))
                    : BorderRadius.zero,
                color: Colors.white),
            child: Column(
              children: [
                Container(
                  height: 100,
                  decoration: BoxDecoration(
                    color: Colors.orange,
                    borderRadius: drawerstatus == true
                        ? BorderRadius.only(topLeft: Radius.circular(50))
                        : BorderRadius.zero,
                  ),
                  child: Padding(
                    padding: const EdgeInsets.only(top: 20, left: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        drawerstatus == false
                            ? IconButton(
                                onPressed: () {
                                  draweranimation.opendrawer();
                                },
                                icon: Icon(CupertinoIcons.list_bullet_indent,
                                    color: Colors.white))
                            : IconButton(
                                onPressed: () {
                                  draweranimation.closedrawer();
                                },
                                icon: Icon(
                                  EvaIcons.arrowBack,
                                  size: 30,
                                )),
                        RichText(
                            text: TextSpan(
                                style: Theme.of(context)
                                    .textTheme
                                    .headline6
                                    ?.copyWith(
                                        fontWeight: FontWeight.w800,
                                        fontFamily: 'poppins'),
                                children: [
                              TextSpan(
                                  text: 'Bakery',
                                  style: TextStyle(color: Colors.white)),
                              TextSpan(
                                  text: 'Shop',
                                  style: TextStyle(color: Colors.deepOrange))
                            ])),
                        IconButton(
                            onPressed: () {
                              Navigator.push(context,
                                  MaterialPageRoute(builder: (context) {
                                return Cart();
                              }));
                            },
                            icon:
                                Icon(CupertinoIcons.cart, color: Colors.white))
                      ],
                    ),
                  ),
                ),
                SingleChildScrollView(
                  child: Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            color: Colors.orange[500],
                            borderRadius: BorderRadius.only(
                                bottomLeft: Radius.circular(60),
                                bottomRight: Radius.circular(60))),
                        padding: EdgeInsets.fromLTRB(0, 0, 0, 50),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 15, vertical: 15),
                          child: Card(
                            shape: StadiumBorder(),
                            elevation: 50,
                            child: Container(
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20)),
                              child: Column(
                                children: [
                                  Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(20, 0, 0, 0),
                                    child: TextFormField(
                                      cursorHeight: 20,
                                      cursorColor: Colors.orange,
                                      decoration: InputDecoration(
                                        hintText: 'search',
                                        hintStyle: TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.w300,
                                            fontFamily: 'poppins'),
                                        border: InputBorder.none,
                                        suffixIcon: IconButton(
                                            onPressed: () {},
                                            icon: Icon(
                                              CupertinoIcons.search,
                                              color: Colors.orange,
                                            )),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Recomended(),

// ! -------------------------- logout button -------------------------------------------

                      TextButton(
                          onPressed: () async {
                            if (_auth.currentUser?.providerData[0].providerId ==
                                'google.com') {
                              print(
                                  'before user data ====> $useremail,$userphotourl,$username');

                              useremail = null;
                              userphotourl = null;
                              username = null;
                              await _auth.signOut();
                              print(
                                  'after user data ====> $useremail,$userphotourl,$username');
                              await Provider.of<Authentication>(context,
                                      listen: false)
                                  .signoutwithgoogle()
                                  .whenComplete(() {
                                users = null;

                                return Navigator.pushAndRemoveUntil(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => Signin()),
                                    (route) => false);
                              });
                            } else {
                              await _auth.signOut();

                              Navigator.pushAndRemoveUntil(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => Signin()),
                                  (route) => false);
                            }
                          },
                          child: Text(
                            "logout",
                            style: TextStyle(color: Colors.black),
                          )),
                      TextButton(
                          onPressed: () async {
                            bool _serviceenabled;
                            PermissionStatus _permissionStatus;
                            // Future<LocationData> _locationdata;

                            _serviceenabled =
                                await Location.instance.serviceEnabled();
                            if (!_serviceenabled) {
                              _serviceenabled =
                                  await Location.instance.requestService();
                              if (!_serviceenabled) {
                                String err = "Please Enable Location";
                                return showsuccesssnackbar(context, err);
                              }
                            }
                            _permissionStatus =
                                await Location.instance.hasPermission();
                            if (_permissionStatus == PermissionStatus.denied) {
                              _permissionStatus =
                                  await Location.instance.requestPermission();
                              if (_permissionStatus !=
                                  PermissionStatus.granted) {
                                if (_permissionStatus ==
                                    PermissionStatus.denied) {
                                  _permissionStatus = await Location.instance
                                      .requestPermission();
                                }
                                _permissionStatus =
                                    await Location.instance.requestPermission();
                                String err =
                                    "Please Give Permission For Location";
                                return showsuccesssnackbar(context, err);
                              }
                            }
                            if (_serviceenabled &&
                                _permissionStatus == PermissionStatus.granted) {
                              (Provider.of<GenerateMaps>(context, listen: false)
                                      .getcurrentlocation())
                                  .whenComplete(() {
                                Provider.of<Changeaddress>(context,
                                        listen: false)
                                    .cleanadd();
                                return Navigator.push(context,
                                    MaterialPageRoute(builder: (context) {
                                  return Googlemaps();
                                }));
                              });
                            }
                          },
                          child: Text('Map'))
                    ],
                  ),
                ),
              ],
            ),
          )),
    );
  }

  void showsuccesssnackbar(BuildContext context, err) {
    final snackBar = SnackBar(
      content: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Icon(
            Icons.error_outline,
            size: 32,
          ),
          const SizedBox(
            width: 16,
          ),
          Expanded(
              child: Text(
            '$err',
            style: TextStyle(fontSize: 20, color: Colors.black),
          ))
        ],
      ),
      backgroundColor: Colors.blue[100],
      behavior: SnackBarBehavior.floating,
      duration: Duration(seconds: 3),
      margin: EdgeInsets.symmetric(vertical: 18, horizontal: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      elevation: 15,
    );

    ScaffoldMessenger.of(context)..hideCurrentSnackBar();
    ScaffoldMessenger.of(context)..showSnackBar(snackBar);
  }
}
