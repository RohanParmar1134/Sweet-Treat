class Userprofile {
  String? displayname;
  String? email;
  String? photo;
  Userprofile({this.displayname, this.email, this.photo});
}
