import 'package:flutter/material.dart';

final rprimarycolor = Color.fromRGBO(249, 124, 0, 1);
